<div class="container text-center">
    <p class="small mb-0 p-3">
        {!! sprintf(
            lang('igniter::main.site_copyright'),
            date('Y'),
            setting('site_name'),
            lang('igniter::system.system_name')
        ).lang('igniter::system.system_powered') !!}
    </p>
</div>
