---
title: Error page (500)
layout: default
permalink: /error
---
<div class="jumbotron">
    <div class="container">
        <h1>Error</h1>
        <p>We're sorry, but something went wrong and the page cannot be displayed.</p>
    </div>
</div>